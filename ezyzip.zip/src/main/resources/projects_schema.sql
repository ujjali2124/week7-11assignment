DROP TABLE IF EXISTS project;
DROP TABLE IF EXISTS material;
DROP TABLE IF EXISTS step;
DROP TABLE IF EXISTS category;
DROP TABLE IF EXISTS project_category;

CREATE TABLE project (
project_id INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
project_name VARCHAR(128) NOT NULL,
estimated_hours decimal(7,2),
actual_hours decimal(7,2),
difficulty INT,
notes TEXT
);

CREATE TABLE material (
material_id INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
FOREIGN KEY (project_id) REFERENCES project (project_id) ON DELETE CASCADE,
material_name VARCHAR(128) NOT NULL,
num_required VARCHAR(128),
cost decimal(7,2)
);

CREATE TABLE step (
step_id INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
FOREIGN KEY (project_id) REFERENCES project (project_id) ON DELETE CASCADE,
step_text TEXT NOT NULL,
step_oredr INT NOT NULL
);

CREATE TABLE category (
category_id INT NOT NULL PRIMARY KEY,
category_name VARCHAR(128) NOT NULL
);

CREATE TABLE project_category (
FOREIGN KEY (project_id) REFERENCES project (project_id) ON DELETE CASCADE,
UNIQUE KEY (project_id, category_id),
FOREIGN KEY (category_id) REFERENCES category (category_id) ON DELETE CASCADE,
UNIQUE KEY (category_id, project_id)
);
