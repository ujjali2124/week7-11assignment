import recipes.dao.DbConnection;

public class Recipes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DbConnection.getConnection();
	}

}
